# Bayes_eu
Analyzing European countries covid polices with Bayesian statistics and deep learning
